#include "DataSet.h"
#include "DataSymbolProcessing.h"
unsigned long long int DataSet::GetMicrosecsElapsed()
{

    return m_lmicrosecsElapsed;
}

string DataSet::GetSymbol()
{
    return m_symbol;
}

unsigned int DataSet::GetQuantity()
{
    return m_quantity;
}

unsigned int DataSet::GetPrice()
{
    return m_price;
}

void DataSet::SetMicrosecsElapsed(unsigned long long int inputTimeEntry)
{
    m_lmicrosecsElapsed = inputTimeEntry;
}

void DataSet::SetSymbol(string sym)
{
    m_symbol = sym;
}

void DataSet::SetQuantity(unsigned int qty)
{
    m_quantity = qty;
}

void DataSet::SetPrice(unsigned int price)
{
    m_price = price;
}

void DataSet::TriggerSymbolProcessing()
{
    OutputFinalResults *ofr = new OutputFinalResults();
    ofr->ProcessEntry(*this);
}

//Send entry to Data processing 