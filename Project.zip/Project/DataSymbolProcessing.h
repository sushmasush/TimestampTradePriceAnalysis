#pragma once

#include "DataSet.h"
#include <unordered_map>
#include <map>
#include <vector>
#include <utility>
#include <sstream>
#include <fstream>

class DataSymbolProcessing
{
	unsigned int m_iMaxTimeGap; 
	int m_iTotalTrades; 
	int m_iMaxTradePrice; 
	int m_iWeightedPrice; 
	unsigned long long  m_prevTimeEntry;

public: 
	DataSymbolProcessing();
	~DataSymbolProcessing();
	unsigned long long GetPrevTimeEntry();
	void SetPrevTimeEntry(unsigned long long);
	bool IsMaxTimeGap(int); 
	void UpdateMaxTimeGap(unsigned long long int ); // get th new max 
	void SetTotalTrades( int);
	int UpdateWeightedPrice(int, int);
	bool IsMaxTradePrice(int);
	void UpdateMaxPrice(int);
	int GetTotalVolume();
	int GetWeightedAvgPrice(); 
	int GetMaxTimeGap();
	int GetWeightedAveragePrice(); 
	int GetMaxPrice();
};

using  MapResultsPerSymbol = map<string,DataSymbolProcessing>;
class OutputFinalResults
{
	MapResultsPerSymbol  m_mapResult;
public: 
	MapResultsPerSymbol GetResultsMap();
	void SetResultMap(MapResultsPerSymbol);
	void ProcessEntry(DataSet &in);
	void WriteResults(string out); 
};
