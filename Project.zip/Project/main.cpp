#include "DataExtractParsing.h"

int main(int argv, char* argc[])
{
	DataExtractParsing *dp = new DataExtractParsing();
	dp->SetInputFileName("C:\\Astudy\\UbuntuShare\\QuantLab\\input.csv");
	//dp->OpenFile("C:\\Astudy\\Interviews\\QuantLab\\simple.csv");
	dp->SetOutputFile("C:\\Astudy\\UbuntuShare\\QuantLab\\output.csv");
	dp->Parsing();

}