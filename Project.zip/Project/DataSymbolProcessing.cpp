#include "DataSymbolProcessing.h"

DataSymbolProcessing::DataSymbolProcessing()
{
	m_iMaxTimeGap = 0;
	m_iTotalTrades = 0;
	m_iMaxTradePrice = 0;
	m_iWeightedPrice = 0;
	m_prevTimeEntry = 0;
}

DataSymbolProcessing::~DataSymbolProcessing()
{
}

unsigned long long DataSymbolProcessing::GetPrevTimeEntry()
{
	return m_prevTimeEntry;
}

void DataSymbolProcessing::SetPrevTimeEntry(unsigned long long curEntry )
{
	m_prevTimeEntry = curEntry;
}

bool DataSymbolProcessing::IsMaxTimeGap(int timeGap)
{
	if (m_iMaxTimeGap < timeGap)
	{
		return true;
	}
	return false;
}

void DataSymbolProcessing::UpdateMaxTimeGap(unsigned long long int newTimeGap)
{
	if (IsMaxTimeGap(newTimeGap))
	{
		m_iMaxTimeGap = newTimeGap;
	}
}

void DataSymbolProcessing::SetTotalTrades(int newItem )
{
	m_iTotalTrades += newItem;

}

int DataSymbolProcessing::UpdateWeightedPrice(int qty, int price)
{
	m_iWeightedPrice += (qty * price);
	return 0;
}

int DataSymbolProcessing::GetWeightedAvgPrice()
{
	return (m_iWeightedPrice / m_iTotalTrades);
}

int DataSymbolProcessing::GetMaxTimeGap()
{
	return m_iMaxTimeGap;
}

int DataSymbolProcessing::GetWeightedAveragePrice()
{
	return (m_iWeightedPrice/m_iTotalTrades);
}

int DataSymbolProcessing::GetMaxPrice()
{
	return m_iMaxTradePrice;
}

bool DataSymbolProcessing::IsMaxTradePrice(int curPrice)
{
	if (m_iMaxTradePrice < curPrice)
	{
		return true;
	}
	return false;
}

void DataSymbolProcessing::UpdateMaxPrice(int price)
{
	if (IsMaxTradePrice(price))
	{
		m_iMaxTradePrice = price;
	}
	
	return ;
}

int DataSymbolProcessing::GetTotalVolume()
{
	return m_iTotalTrades;
}

MapResultsPerSymbol OutputFinalResults::GetResultsMap()
{
	return m_mapResult;
}

void OutputFinalResults::SetResultMap(MapResultsPerSymbol input)
{
	m_mapResult = input;
}

void OutputFinalResults::ProcessEntry(DataSet &in)
{
	auto mapResults = GetResultsMap();
	auto itr = mapResults.find(in.GetSymbol());

	if (itr == mapResults.end())
	{
		//add the entry
		DataSymbolProcessing* dsp = new DataSymbolProcessing();
		dsp->SetPrevTimeEntry(in.GetMicrosecsElapsed());
		dsp->SetTotalTrades(in.GetQuantity());
		dsp->UpdateMaxPrice(in.GetPrice());
		dsp->UpdateMaxTimeGap(0);
		dsp->UpdateWeightedPrice(in.GetQuantity(),in.GetPrice());
		//mapResults[in.GetSymbol()] = *dsp;
		if (auto [iter, success] = mapResults.insert(make_pair(in.GetSymbol(), *dsp)); success)
		{
			SetResultMap(mapResults);
		}
		else
		{
			cout << "Some error in insertion to map" << endl;
		}
	}
	else
	{
		// update the entry 
		DataSymbolProcessing dp = mapResults[in.GetSymbol()];
		unsigned long long currEntry = in.GetMicrosecsElapsed();
		unsigned long long prevEntry = dp.GetPrevTimeEntry();

		//update the time gap 
		dp.UpdateMaxTimeGap(currEntry-prevEntry);

		//update prev entry to the curr one
		dp.SetPrevTimeEntry(currEntry);
		
		//Update totale volume 
		dp.SetTotalTrades(in.GetQuantity());

		dp.UpdateWeightedPrice(in.GetQuantity(), in.GetPrice());

		dp.UpdateMaxPrice(in.GetPrice());
		
		//update the value of the map after updating the respective values 
		mapResults[in.GetSymbol()] = dp;
		SetResultMap(mapResults);
	}
}

template<typename ...Args>
void FoldCout(Args&&... args) {
	(cout << ... << (args)) << '\n';
}

void OutputFinalResults::WriteResults(string outFileName)
{
	stringstream ss;
	ofstream outFile(outFileName);
	for (const auto& [key, value] : m_mapResult)
	{
		DataSymbolProcessing dsp = value;
		//Debugging purpose
		FoldCout("Symbol: ",key,  "\n", "MaxTime gap", dsp.GetMaxTimeGap(),"\n", "Volume",
		 dsp.GetTotalVolume(), "\n", "Weighted Avg price", dsp.GetWeightedAveragePrice(), "\n",
			"Max Price", dsp.GetMaxPrice(),"\n");

		ss << key << "," << dsp.GetMaxTimeGap() << "," << dsp.GetTotalVolume() << ","
			<< dsp.GetWeightedAveragePrice() << ","
			<< dsp.GetMaxPrice() << endl;
	}
	
	if (outFile.is_open())
	{
		outFile << ss.str();
	}
	else
	{
		cout << "Unable to open the output file " << endl;
	}
}
