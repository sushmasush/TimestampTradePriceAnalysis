#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include<vector>
#include<unordered_map>
#include "DataSet.h"
#include <sstream>
using namespace std; 

//Read a CSV and add this object 
class DataExtractParsing
{
	string inputFile; 
	string outputFile; 
	ifstream m_inputFileStream;
	
public: 
	DataExtractParsing();
	~DataExtractParsing();

	void SetInputFileName(string);
	string GetInputFileName();
	bool OpenFile(string in);
	bool CloseFile(ifstream );
	void SetOutputFile(string out);
	void Parsing();
};