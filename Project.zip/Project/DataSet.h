#pragma once
#include <iostream>
#include <string>
//<TimeStamp>,<Symbol>,<Quantity>,<Price>
using namespace std; 

//hungarian notation 
//Every line in the file is of type dataset 
class DataSet
{
	unsigned long long int m_lmicrosecsElapsed; 
	string m_symbol; 
	unsigned int m_quantity; 
	unsigned int m_price;

public: 
	//Get methods
	unsigned long long int GetMicrosecsElapsed();
	string GetSymbol();
	unsigned int GetQuantity();
	unsigned int GetPrice();

	//Set methods
	void SetMicrosecsElapsed(unsigned long long int);
	void SetSymbol(string);
	void SetQuantity(unsigned int);
	void SetPrice(unsigned int);
	void TriggerSymbolProcessing();

};