#include "DataExtractParsing.h"
#include "DataSymbolProcessing.h"

DataExtractParsing::DataExtractParsing()
{

}
DataExtractParsing::~DataExtractParsing()
{
	m_inputFileStream.close();
}
void DataExtractParsing::SetInputFileName(string filename)
{
	inputFile = filename;
}

string DataExtractParsing::GetInputFileName()
{
	return inputFile;
}

constexpr int sum(int a, int b)
{
	return a + b; 
}


bool DataExtractParsing::OpenFile(string  in)
{
	m_inputFileStream.open(in);
	if (m_inputFileStream.is_open())
		return true;
	return false;
}

bool DataExtractParsing::CloseFile(ifstream fileStream)
{
	if (fileStream.is_open())
	{
		fileStream.close();
		return true; //success
	}
	return false;
}

void DataExtractParsing::SetOutputFile(string out)
{
	outputFile = out;
}

void DataExtractParsing::Parsing()
{
	string line;
	int count = 0; 
	m_inputFileStream.open(GetInputFileName());
	if (m_inputFileStream.is_open())
	{
 		OutputFinalResults* ofr = new OutputFinalResults();
		while ((getline(m_inputFileStream, line)))
		{
	
			DataSet *item = new DataSet();
			string s = line;
			std::string delimiter = ",";
			std::string token = s.substr(0, s.find(delimiter)); // token is tab
			auto start = 0U;
			auto end = s.find(delimiter);
			int attrCount = 0;

			while (end != std::string::npos)
			{
				attrCount++;
				string substring = s.substr(start, end - start);
				//Can be extended later.. think about this
				if (attrCount == 1)
				{
					item->SetMicrosecsElapsed(stoull(substring));
				}
				else if (attrCount == 2)
				{
					item->SetSymbol(substring);
				}
				else if (attrCount ==3)
				{
					item->SetQuantity(stoi(substring));
				}
				start = end + delimiter.length();
				end = s.find(delimiter, start);
			}
			//Attribute column -4 
			item->SetPrice(stoi( s.substr(start, s.length() - start)));

			//Process the data 
			ofr->ProcessEntry(*item);
		}
		m_inputFileStream.close();
		//Write Results 
		ofr->WriteResults(outputFile);
	}
}